package operasimatriks;

import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

/**
 *
 * @author Umar Al-Faruq
 */
public class OperasiMatriks {

    Scanner sc;

    public OperasiMatriks() {
        sc = new Scanner(System.in);
    }

    public static void main(String[] args) {
        /*
        * auto input matriks pertama
        **/
        int[][] A = new int[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                A[i][j] = ThreadLocalRandom.current().nextInt(-16, 16);
            }
        }

        /*
        * auto input matriks kedua
        **/
        int[][] B = new int[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                B[i][j] = ThreadLocalRandom.current().nextInt(-16, 16);
            }
        }

        OperasiMatriks om = new OperasiMatriks();

        System.out.println("Matriks A");
        om.cetak(A);
        System.out.println("");
        System.out.println("Matriks B");
        om.cetak(B);
        System.out.println("");

        om.displayMenu();
        om.play(A, B);
    }

    public void displayMenu() {
        System.out.println("Menu operasi");
        System.out.println("   1. Penjumlahan\n"
                + "   2. Pengurangan\n"
                + "   3. Perkalian\n"
                + "   4. Perkalian dengan skalar\n"
                + "   5. Transpose\n"
                + "   0. Keluar");
    }

    public void play(int[][] A, int[][] B) {
        OperasiMatriks om = new OperasiMatriks();
        int p;
        do {
            Scanner sc = new Scanner(System.in);
            int[][] C;
            System.out.print("Pilih operasi : ");
            p = sc.nextInt();

            switch (p) {
                case 1:
                    System.out.println("Hasil A + B = ");
                    C = om.countPenjumlahan(A, B);
                    om.cetak(C);
                    System.out.println("");
                    break;
                case 2:
                    System.out.println("Hasil A - B = ");
                    C = om.countPengurangan(A, B);
                    om.cetak(C);
                    System.out.println("");
                    break;
                case 3:
                    System.out.println("Hasil A * B = ");
                    C = om.countPerkalian(A, B);
                    om.cetak(C);
                    System.out.println("");
                    break;
                case 4:
                    System.out.println("Hasil k * A = ");
                    C = om.countPerkalianSkalar(A);
                    om.cetak(C);
                    System.out.println("");

                    System.out.println("Hasil k * B = ");
                    C = om.countPerkalianSkalar(B);
                    om.cetak(C);
                    System.out.println("");
                    break;
                case 5:
                    System.out.println("Hasil transpose A = ");
                    C = om.transpose(A);
                    om.cetak(C);
                    System.out.println("");

                    System.out.println("Hasil transpose B = ");
                    C = om.transpose(B);
                    om.cetak(C);
                    System.out.println("");
                    break;
                default:
                    System.out.println("Terima kasih");
            }
        } while (p != 0);
        sc.close();
    }
    
    public void cetak(int[][] x) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(x[i][j] + "\t");
            }
            System.out.println("");
        }
    }

    public int[][] countPenjumlahan(int[][] x, int[][] y) {
        int[][] hasil = new int[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                hasil[i][j] = x[i][j] + y[i][j];
            }
        }
        return hasil;
    }

    public int[][] countPengurangan(int[][] x, int[][] y) {
        int[][] hasil = new int[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                hasil[i][j] = x[i][j] - y[i][j];
            }
        }
        return hasil;
    }

    public int[][] countPerkalian(int[][] x, int[][] y) {
        int[][] hasil = new int[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                hasil[i][j] = 0;
                for (int k = 0; k < 3; k++) {
                    hasil[i][j] += x[i][k] * y[k][j];
                }
            }
        }
        return hasil;
    }

    public int[][] countPerkalianSkalar(int[][] x) {
        int[][] hasil = new int[3][3];
        System.out.print("Masukkan nilai skalar : ");
        int k = sc.nextInt();
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                hasil[i][j] = k * x[i][j];
            }
        }
        return hasil;
    }

    public int[][] transpose(int[][] x) {
        int[][] hasil = new int[3][3];
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                hasil[i][j] = x[j][i];
            }
        }
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                hasil[i][j] = hasil[i][j];
            }
        }
        return hasil;
    }
}
